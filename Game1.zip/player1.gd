extends CharacterBody3D

@export var move_speed := 4.0
@export var look_sensitivity := 0.004
@export var gravity := 12.0
@export var mouse_sensitivity := 0.0025

@onready var camera: Camera3D = $Camera3D

var move_input := Vector2.ZERO
var pitch := 0.0
var mouse_look := false


func _ready() -> void:
	var controls = get_node_or_null("../CanvasLayer/MobileControls")

	if controls:
		controls.move_changed.connect(_on_move_changed)
		controls.look_changed.connect(_on_look_changed)

	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)


func _on_move_changed(value: Vector2) -> void:
	move_input = value


func _on_look_changed(value: Vector2) -> void:
	rotate_y(-value.x * look_sensitivity)

	pitch = clamp(
		pitch - value.y * look_sensitivity,
		deg_to_rad(-80.0),
		deg_to_rad(80.0)
	)

	camera.rotation.x = pitch


func _unhandled_input(event: InputEvent) -> void:

	# PC mouse look
	if event is InputEventMouseMotion:
		if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
			rotate_y(-event.relative.x * mouse_sensitivity)

			pitch = clamp(
				pitch - event.relative.y * mouse_sensitivity,
				deg_to_rad(-80.0),
				deg_to_rad(80.0)
			)

			camera.rotation.x = pitch

	# Escape releases mouse
	elif event is InputEventKey:
		if event.keycode == KEY_ESCAPE and event.pressed:
			Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)

	# Left click captures mouse again
	elif event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
			Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)


func _physics_process(delta: float) -> void:

	# --------------------------------
	# KEYBOARD INPUT
	# --------------------------------

	var keyboard := Input.get_vector(
		"move_left",
		"move_right",
		"move_forward",
		"move_back"
	)

	# Keyboard overrides mobile movement
	# when WASD is being used.
	if keyboard.length() > 0.01:
		move_input = keyboard

	# If neither keyboard nor mobile joystick
	# is being used, stop horizontal movement.
	elif not _mobile_move_active():
		move_input = Vector2.ZERO


	# --------------------------------
	# PLAYER-RELATIVE MOVEMENT
	# --------------------------------

	# Player's right direction
	var right := global_transform.basis.x

	# Player's forward direction
	# In Godot 3D, forward is -Z.
	var forward := -global_transform.basis.z

	# Combine joystick/keyboard X and Y
	var direction := right * move_input.x + forward * move_input.y

	# Don't allow movement input to affect height.
	direction.y = 0.0

	# Prevent diagonal movement from being faster.
	if direction.length() > 0.01:
		direction = direction.normalized()


	# --------------------------------
	# APPLY MOVEMENT
	# --------------------------------

	velocity.x = direction.x * move_speed
	velocity.z = direction.z * move_speed


	# --------------------------------
	# GRAVITY
	# --------------------------------

	if not is_on_floor():
		velocity.y -= gravity * delta
	else:
		velocity.y = -0.1


	# --------------------------------
	# MOVE PLAYER
	# --------------------------------

	move_and_slide()


func _mobile_move_active() -> bool:
	var controls = get_node_or_null("../CanvasLayer/MobileControls")

	if controls and "move_touch" in controls:
		return controls.move_touch != -1

	return false
